# Lab 2: Analysis and Detection of Evasion Behavior

## Mục tiêu
Điều tra giới hạn của quá trình quét archive được bảo vệ bằng mật khẩu và thu thập bằng chứng từ nội dung đáng ngờ.

## Task 1: Scan Comparison
So sánh kết quả quét trước và sau khi archive được xử lý.
- Xác định những điểm khác biệt quan trọng.
- Tìm tên file được đánh dấu cần kiểm tra thủ công.
- Giải thích vì sao kết quả quét ban đầu chưa đủ để kết luận archive an toàn.

## Task 2: Log Analysis
Điều tra log để dựng lại trình tự sự kiện.
- Xác định nguyên nhân nội dung archive chưa được kiểm tra trong lần quét đầu.
- Tìm thời điểm archive được giải nén và gửi quét lại.
- Xác định tên file cần điều tra tiếp theo.

## Task 3: Evidence Collection
Tiếp tục điều tra dựa trên kết quả của hai nhiệm vụ trước.
- Tìm và giải nén archive bằng mật khẩu đã được cung cấp.
- Xác định nội dung liên quan đến yêu cầu thay đổi tài khoản thanh toán.
- Ghi nhận tên file và bằng chứng hỗ trợ kết luận.

## Hoàn thành
Đảm bảo đã thực hiện đủ các bước điều tra và kết thúc lab theo hướng dẫn Labtainer.
