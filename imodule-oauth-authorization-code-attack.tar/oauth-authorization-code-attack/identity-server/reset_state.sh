#!/bin/bash

DATA_DIR="$(dirname "$0")/data"

cat > "$DATA_DIR/applications.json" <<'EOF'
{
  "applications": []
}
EOF

cat > "$DATA_DIR/consents.json" <<'EOF'
{
  "consents": []
}
EOF

cat > "$DATA_DIR/authorization_codes.json" <<'EOF'
{
  "authorization_codes": []
}
EOF

cat > "$DATA_DIR/tokens.json" <<'EOF'
{
  "tokens": []
}
EOF

cat > "$DATA_DIR/pending_requests.json" <<'EOF'
{
  "requests": []
}
EOF

rm -f "$(dirname "$0")/logs/"*

echo "Identity Server state has been reset."
