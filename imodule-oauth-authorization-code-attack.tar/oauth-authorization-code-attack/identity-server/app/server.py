import os
import json
import time
import secrets
import hashlib
import base64
from urllib.parse import urlencode

from flask import Flask, request, jsonify, redirect, render_template

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "..", "data")
LOG_DIR = os.path.join(BASE_DIR, "..", "logs")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

USER_FILE = os.path.join(DATA_DIR, "users.json")
APP_FILE = os.path.join(DATA_DIR, "applications.json")
CONSENT_FILE = os.path.join(DATA_DIR, "consents.json")
CODE_FILE = os.path.join(DATA_DIR, "authorization_codes.json")
TOKEN_FILE = os.path.join(DATA_DIR, "tokens.json")
PENDING_FILE = os.path.join(DATA_DIR, "pending_requests.json")

ATTACKER_CALLBACK = "http://attacker:8000/callback"
RESOURCE_SERVER = "http://resource-server:6000"

CODE_LIFETIME = 180
PENDING_LIFETIME = 300
TOKEN_LIFETIME = 3600

ALLOWED_SCOPES = {
    "mail.read",
    "contacts.read",
    "documents.read"
}


def load_json(path, default):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def save_json(path, data):
    temp_path = path + ".tmp"

    with open(temp_path, "w") as f:
        json.dump(data, f, indent=2)

    os.replace(temp_path, path)


def log_event(message):
    log_path = os.path.join(LOG_DIR, "oauth_activity.log")

    with open(log_path, "a") as f:
        f.write(f"{int(time.time())} | {message}\n")


def get_application(client_id):
    data = load_json(APP_FILE, {"applications": []})

    for application in data["applications"]:
        if application["client_id"] == client_id:
            return application

    return None


def encode_state(value):
    return urlencode({"state": value})


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "service": "identity-server",
        "status": "ok"
    })


@app.route("/.well-known/oauth-authorization-server", methods=["GET"])
def metadata():
    return jsonify({
        "issuer": "http://identity-server:5000",
        "authorization_endpoint": "http://identity-server:5000/oauth/authorize",
        "token_endpoint": "http://identity-server:5000/oauth/token",
        "introspection_endpoint": "http://identity-server:5000/oauth/introspect",
        "registration_endpoint": "http://identity-server:5000/register",
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code"],
        "code_challenge_methods_supported": ["S256"],
        "scopes_supported": sorted(ALLOWED_SCOPES)
    })


@app.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}

    client_name = data.get("client_name", "").strip()
    redirect_uri = data.get("redirect_uri", "").strip()
    client_type = data.get("client_type", "")

    if not client_name:
        return jsonify({"error": "invalid_client_name"}), 400

    if redirect_uri != ATTACKER_CALLBACK:
        return jsonify({"error": "invalid_redirect_uri"}), 400

    if client_type != "public":
        return jsonify({"error": "unsupported_client_type"}), 400

    client_id = "cli_" + secrets.token_hex(8)

    application = {
        "client_id": client_id,
        "client_name": client_name,
        "publisher": "Unverified Publisher",
        "client_type": "public",
        "redirect_uri": redirect_uri,
        "created_at": int(time.time())
    }

    applications = load_json(APP_FILE, {"applications": []})
    applications["applications"].append(application)
    save_json(APP_FILE, applications)

    log_event(f"APPLICATION_REGISTERED client_id={client_id}")

    return jsonify({
        "client_id": client_id,
        "client_name": client_name,
        "redirect_uri": redirect_uri,
        "client_type": client_type
    }), 201


@app.route("/oauth/authorize", methods=["GET"])
def authorize():
    client_id = request.args.get("client_id", "")
    redirect_uri = request.args.get("redirect_uri", "")
    response_type = request.args.get("response_type", "")
    scope_string = request.args.get("scope", "")
    state = request.args.get("state", "")
    code_challenge = request.args.get("code_challenge", "")
    code_challenge_method = request.args.get("code_challenge_method", "")

    application = get_application(client_id)

    if not application:
        return jsonify({"error": "invalid_client"}), 400

    if redirect_uri != application["redirect_uri"]:
        return jsonify({"error": "invalid_redirect_uri"}), 400

    if response_type != "code":
        return jsonify({"error": "unsupported_response_type"}), 400

    if not state:
        return jsonify({"error": "missing_state"}), 400

    if code_challenge_method != "S256" or not code_challenge:
        return jsonify({"error": "invalid_pkce_parameters"}), 400

    scopes = scope_string.split()

    if not scopes or len(scopes) != len(set(scopes)):
        return jsonify({"error": "invalid_scope"}), 400

    if not set(scopes).issubset(ALLOWED_SCOPES):
        return jsonify({"error": "invalid_scope"}), 400

    request_id = secrets.token_urlsafe(16)

    pending = load_json(PENDING_FILE, {"requests": []})

    pending["requests"].append({
        "request_id": request_id,
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scopes": scopes,
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": code_challenge_method,
        "created_at": int(time.time())
    })

    save_json(PENDING_FILE, pending)

    log_event(f"AUTHORIZATION_REQUEST client_id={client_id}")

    return redirect(
        f"/oauth/consent?request_id={request_id}"
    )


@app.route("/oauth/consent", methods=["GET"])
def consent_page():
    request_id = request.args.get("request_id", "")

    pending = load_json(PENDING_FILE, {"requests": []})

    auth_request = next(
        (item for item in pending["requests"]
         if item["request_id"] == request_id),
        None
    )

    if not auth_request:
        return "Invalid or expired authorization request.", 400

    if time.time() - auth_request["created_at"] > PENDING_LIFETIME:
        return "Authorization request has expired.", 400

    application = get_application(auth_request["client_id"])

    if not application:
        return "Application not found.", 400

    return render_template(
        "consent.html",
        application=application,
        scopes=auth_request["scopes"],
        request_id=request_id
    )


@app.route("/oauth/consent", methods=["POST"])
def consent_decision():
    request_id = request.form.get("request_id", "")
    decision = request.form.get("decision", "")

    if decision not in ("allow", "deny"):
        return "Invalid consent decision.", 400

    pending = load_json(PENDING_FILE, {"requests": []})

    auth_request = next(
        (item for item in pending["requests"]
         if item["request_id"] == request_id),
        None
    )

    if not auth_request:
        return "Invalid or expired authorization request.", 400

    if time.time() - auth_request["created_at"] > PENDING_LIFETIME:
        return "Authorization request has expired.", 400

    application = get_application(auth_request["client_id"])

    if not application:
        return "Application not found.", 400

    # Consume the pending request only after validation.
    pending["requests"] = [
        item for item in pending["requests"]
        if item["request_id"] != request_id
    ]
    save_json(PENDING_FILE, pending)

    if decision == "deny":
        log_event(
            f"CONSENT_DENIED client_id={auth_request['client_id']}"
        )

        params = {
            "error": "access_denied",
            "state": auth_request["state"]
        }

        return redirect(
            auth_request["redirect_uri"] + "?" + urlencode(params)
        )

    user_data = load_json(USER_FILE, {"users": []})

    if not user_data["users"]:
        return "No simulated user available.", 500

    user = user_data["users"][0]

    consent = {
        "client_id": auth_request["client_id"],
        "user_id": user["user_id"],
        "scopes": auth_request["scopes"],
        "granted_at": int(time.time())
    }

    consents = load_json(CONSENT_FILE, {"consents": []})
    consents["consents"].append(consent)
    save_json(CONSENT_FILE, consents)

    code = secrets.token_urlsafe(24)

    authorization_code = {
        "code": code,
        "client_id": auth_request["client_id"],
        "redirect_uri": auth_request["redirect_uri"],
        "user_id": user["user_id"],
        "scopes": auth_request["scopes"],
        "code_challenge": auth_request["code_challenge"],
        "created_at": int(time.time()),
        "used": False
    }

    codes = load_json(CODE_FILE, {"authorization_codes": []})
    codes["authorization_codes"].append(authorization_code)
    save_json(CODE_FILE, codes)

    log_event(
        f"CONSENT_GRANTED client_id={auth_request['client_id']} "
        f"user_id={user['user_id']}"
    )

    params = {
        "code": code,
        "state": auth_request["state"]
    }

    return redirect(
        auth_request["redirect_uri"] + "?" + urlencode(params)
    )


@app.route("/oauth/token", methods=["POST"])
def token():
    data = request.get_json(silent=True) or {}

    grant_type = data.get("grant_type", "")
    code = data.get("code", "")
    client_id = data.get("client_id", "")
    redirect_uri = data.get("redirect_uri", "")
    code_verifier = data.get("code_verifier", "")

    if grant_type != "authorization_code":
        return jsonify({"error": "unsupported_grant_type"}), 400

    codes = load_json(CODE_FILE, {"authorization_codes": []})

    auth_code = next(
        (item for item in codes["authorization_codes"]
         if item["code"] == code),
        None
    )

    if not auth_code:
        return jsonify({"error": "invalid_grant"}), 400

    if auth_code["used"]:
        return jsonify({"error": "invalid_grant"}), 400

    if time.time() - auth_code["created_at"] > CODE_LIFETIME:
        return jsonify({"error": "expired_code"}), 400

    if auth_code["client_id"] != client_id:
        return jsonify({"error": "invalid_client"}), 400

    if auth_code["redirect_uri"] != redirect_uri:
        return jsonify({"error": "invalid_redirect_uri"}), 400

    if not (43 <= len(code_verifier) <= 128):
        return jsonify({"error": "invalid_code_verifier"}), 400

    digest = hashlib.sha256(code_verifier.encode()).digest()
    calculated_challenge = base64.urlsafe_b64encode(
        digest
    ).decode().rstrip("=")

    if not secrets.compare_digest(
        calculated_challenge,
        auth_code["code_challenge"]
    ):
        return jsonify({"error": "invalid_code_verifier"}), 400

    auth_code["used"] = True
    save_json(CODE_FILE, codes)

    access_token = secrets.token_urlsafe(32)

    token_record = {
        "access_token": access_token,
        "client_id": client_id,
        "user_id": auth_code["user_id"],
        "scopes": auth_code["scopes"],
        "created_at": int(time.time()),
        "expires_at": int(time.time()) + TOKEN_LIFETIME
    }

    tokens = load_json(TOKEN_FILE, {"tokens": []})
    tokens["tokens"].append(token_record)
    save_json(TOKEN_FILE, tokens)

    log_event(
        f"TOKEN_ISSUED client_id={client_id} "
        f"user_id={auth_code['user_id']}"
    )

    return jsonify({
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": TOKEN_LIFETIME,
        "scope": " ".join(auth_code["scopes"])
    })


@app.route("/oauth/introspect", methods=["POST"])
def introspect():
    data = request.get_json(silent=True) or {}
    access_token = data.get("token", "")

    tokens = load_json(TOKEN_FILE, {"tokens": []})

    token_record = next(
        (item for item in tokens["tokens"]
         if item["access_token"] == access_token),
        None
    )

    if not token_record:
        return jsonify({"active": False})

    if time.time() >= token_record["expires_at"]:
        return jsonify({"active": False})

    return jsonify({
        "active": True,
        "client_id": token_record["client_id"],
        "user_id": token_record["user_id"],
        "scope": " ".join(token_record["scopes"]),
        "exp": token_record["expires_at"]
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
