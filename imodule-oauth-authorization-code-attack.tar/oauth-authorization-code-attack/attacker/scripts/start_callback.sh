#!/bin/bash

python3 "$(dirname "$0")/callback_server.py"
