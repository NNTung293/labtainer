import os
import json
import requests

from flask import Flask, request, jsonify

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(
    os.path.dirname(BASE_DIR),
    "data",
    "resources.json"
)

IDENTITY_SERVER = "http://identity-server:5000"

LOG_DIR = os.path.expanduser("~/logs")
LOG_FILE = os.path.join(LOG_DIR, "resource_activity.log")

ACCESS_TRACKER = {}


def load_resources():
    with open(DATA_FILE, "r") as file:
        return json.load(file)


def log_access(resource, user_id):
    os.makedirs(LOG_DIR, exist_ok=True)

    with open(LOG_FILE, "a") as file:
        file.write(
            f"RESOURCE_ACCESS_GRANTED user_id={user_id} resource={resource}\n"
        )

    accessed = ACCESS_TRACKER.setdefault(user_id, set())
    accessed.add(resource)

    required_resources = {"emails", "contacts", "documents"}

    if required_resources.issubset(accessed):
        if not ACCESS_TRACKER.get(f"{user_id}_completed"):
            with open(LOG_FILE, "a") as file:
                file.write(
                    f"RESOURCE_ACCESS_SUCCESS user_id={user_id}\n"
                )

            ACCESS_TRACKER[f"{user_id}_completed"] = True


def validate_token():
    auth_header = request.headers.get("Authorization", "")

    if not auth_header.startswith("Bearer "):
        return None, (jsonify({
            "error": "missing_or_invalid_authorization_header"
        }), 401)

    token = auth_header[7:].strip()

    if not token:
        return None, (jsonify({
            "error": "missing_access_token"
        }), 401)

    try:
        response = requests.post(
            IDENTITY_SERVER + "/oauth/introspect",
            json={"token": token},
            timeout=5
        )
        response.raise_for_status()
        result = response.json()

    except requests.RequestException:
        return None, (jsonify({
            "error": "identity_server_unavailable"
        }), 503)

    if not result.get("active"):
        return None, (jsonify({
            "error": "invalid_or_expired_token"
        }), 401)

    return result, None


def require_scope(required_scope):
    token_info, error = validate_token()

    if error:
        return None, error

    granted_scopes = token_info.get("scope", "").split()

    if required_scope not in granted_scopes:
        return None, (jsonify({
            "error": "insufficient_scope",
            "required_scope": required_scope
        }), 403)

    return token_info, None


@app.route("/api/emails", methods=["GET"])
def get_emails():
    token_info, error = require_scope("mail.read")

    if error:
        return error

    resources = load_resources()
    log_access("emails", token_info["user_id"])

    return jsonify({
        "user_id": token_info["user_id"],
        "resource": "emails",
        "data": resources["emails"]
    })


@app.route("/api/contacts", methods=["GET"])
def get_contacts():
    token_info, error = require_scope("contacts.read")

    if error:
        return error

    resources = load_resources()
    log_access("contacts", token_info["user_id"])

    return jsonify({
        "user_id": token_info["user_id"],
        "resource": "contacts",
        "data": resources["contacts"]
    })


@app.route("/api/documents", methods=["GET"])
def get_documents():
    token_info, error = require_scope("documents.read")

    if error:
        return error

    resources = load_resources()
    log_access("documents", token_info["user_id"])

    return jsonify({
        "user_id": token_info["user_id"],
        "resource": "documents",
        "data": resources["documents"]
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "service": "resource-server"
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=6000)
