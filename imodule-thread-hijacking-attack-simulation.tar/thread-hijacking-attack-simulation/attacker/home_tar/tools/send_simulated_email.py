#!/usr/bin/env python3

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from email import policy
from email.parser import BytesParser
from pathlib import Path


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Simulate email delivery locally without network access."
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Path to the input .eml file"
    )
    return parser.parse_args()


def main():
    args = parse_arguments()

    lab_home = Path(__file__).resolve().parent.parent
    input_path = Path(args.input).expanduser()

    if not input_path.is_absolute():
        input_path = Path.cwd() / input_path

    if not input_path.is_file():
        print(f"[ERROR] Input file not found: {input_path}")
        return 1

    try:
        raw_email = input_path.read_bytes()
        message = BytesParser(policy=policy.default).parsebytes(raw_email)
    except (OSError, ValueError) as error:
        print(f"[ERROR] Cannot read input email: {error}")
        return 1

    simulation_dir = lab_home / "simulation"
    outbox_dir = simulation_dir / "outbox"
    log_path = simulation_dir / "simulation_log.json"

    try:
        outbox_dir.mkdir(parents=True, exist_ok=True)

        existing_numbers = []
        for path in outbox_dir.glob("simulated_*.eml"):
            suffix = path.stem.replace("simulated_", "")
            if suffix.isdigit():
                existing_numbers.append(int(suffix))

        next_number = max(existing_numbers, default=0) + 1
        output_path = outbox_dir / f"simulated_{next_number:03d}.eml"

        shutil.copy2(input_path, output_path)

        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "input_file": str(input_path),
            "output_file": str(output_path),
            "from": str(message.get("From", "")),
            "to": str(message.get("To", "")),
            "subject": str(message.get("Subject", "")),
            "message_id": str(message.get("Message-ID", "")),
            "status": "simulated"
        }

        events = []
        if log_path.exists():
            with log_path.open("r", encoding="utf-8") as log_file:
                events = json.load(log_file)

            if not isinstance(events, list):
                raise ValueError("Simulation log must contain a JSON list.")

        events.append(event)

        with log_path.open("w", encoding="utf-8") as log_file:
            json.dump(events, log_file, indent=4, ensure_ascii=False)

    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"[ERROR] Simulation failed: {error}")
        return 1

    print("[SIMULATION] Email processed successfully.")
    print(f"From: {event['from']}")
    print(f"To: {event['to']}")
    print(f"Subject: {event['subject']}")
    print(f"Output: {output_path}")
    print("Status: SIMULATED - No email was sent over the network.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
